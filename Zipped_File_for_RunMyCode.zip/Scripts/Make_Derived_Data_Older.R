# Make derived data - older

# Old HMD
Make_Derived_Data(
    HMD_Location="Data/HMD/Old",
    Country.Codes=Country_Codes_Older,
    Outfile_Location="Data/Derived",
    Outfile_Name="Derived_Data_Older.RData",
    old_HMD=TRUE
)
