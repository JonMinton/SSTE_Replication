# Make derived data - newer

# Old HMD
Make_Derived_Data(
    HMD_Location="Data/HMD/Newer",
    Country.Codes=Country_Codes_Newer,
    Outfile_Location="Data/Derived",
    Outfile_Name="Derived_Data_Newer.RData",
    old_HMD=FALSE
)
